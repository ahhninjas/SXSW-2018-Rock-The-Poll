# alexa-nodejs-boilerplate-lambda

This is a simple boilerplate for alexa skill developement using lambda functions.
